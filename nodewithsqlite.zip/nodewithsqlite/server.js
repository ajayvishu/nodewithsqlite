//express modules import 
var express = require('express');
var app = express();

//bodyparser modules import
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//custom html landing page
app.use(express.static(__dirname+'/root'));

//cors middleware
app.use(function (req, res, next) {
    //enabling CORS 
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");
    next();
});

//sqlite3 modules import 
var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./employee.db', (err) => { 
    if (err) { 
        console.log('error when creating the database', err); 
    } else { 
        //console.log('database created!') 
        db.run(`create table employee (
            id integer primary key autoincrement,
            name text,
			salary real
            )`,(err) => {
			if (err) {
				//table already created
			}else{
				//table just created, creating some rows
				var insert = 'insert into employee (name, salary) values (?,?)';
				db.run(insert, ["ajay",85000])
				db.run(insert, ["dev",75000])
			}
		});
	}			
});

var HTTP_PORT = process.env.PORT || 5005;

//start server
app.listen(HTTP_PORT, () => {
    console.log(`Server running on port ${HTTP_PORT}`);
});

//get all employee data
app.get('/api/employee', function(req,res){
  db.all('select * from employee', function(err,row){     
    if(err){
      res.status(400).json({"error": err.message});
      return;
    }
	res.json({
        "message":"success",
        "data":row
    });
  });
});

//get employee data by id
app.get('/api/employee/:id', function(req,res){
  db.each('select * from employee where id =?', [req.params.id], function(err,row){     
    if(err){
      res.status(400).json({"error": err.message});
      return;
    }
    res.json({
        "message":"success",
        "data":row
    });
  });
});

//add employee record
app.post('/api/employee/', function(req,res){
  var errors = [];
  if (!req.body.name){
      errors.push("name is not specified");
  }
  if (!req.body.salary){
      errors.push("salary is not specified");
  }
  if (errors.length){
      res.status(400).json({"error":errors.join(",")});
      return;
  }
  var data = {
     id: req.body.id,
     name: req.body.name,
     salary: req.body.salary,
  }
  db.run('insert into employee(name,salary) VALUES(?,?)', [data.name, data.salary], function(err) {
    if (err) {
	  res.status(400).json({"error": err.message});
      return;
    }
	res.json({
        "message": "success",
        "data": data
    });
  });
});

//update employee record
app.put('/api/employee/:id', function(req,res){
  var data = {
      name: req.body.name,
      salary: req.body.salary
  }
  db.run(`update employee set 
	name = COALESCE(?,name) ,
	salary = COALESCE(?,salary) 
	where id = ?`,[data.name,data.salary,req.params.id], function(err){
      if(err){
        res.status(400).json({"error": res.message});
        return;
      }
      res.json({
         message: "success",
         data: data,
         changes: this.changes
      });
  });
});

//delete employee record
app.delete('/api/employee/:id', function(req,res){
  db.run('delete from employee where id = ?', req.params.id, function(err) {
    if (err) {
      res.status(400).json({"error": res.message});
      return;
    }
    res.json({"message":"deleted", changes: this.changes});
  });
});

//root path
app.get("/", (req, res, next) => {
    res.json({"message":"ok"});
});